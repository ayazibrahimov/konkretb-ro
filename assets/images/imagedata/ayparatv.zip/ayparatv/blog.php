

    <!-- navbar start -->
    <?php include 'includes/header.php' ?>
    <!-- navbar end -->

    <div class="container">
        <div class="breadcrumb-area">
            <div class="row justify-content-center">
                <div class="col-md-12">
					<h1 class="theme-breacrumb-title">Mədəniyyət</h1>
				</div>
            </div>
        </div>
    </div>
    
    <!-- blog-area start -->
    <div class="blog-area pd-top-100 pd-bottom-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                <div class="col-lg-6 col-md-6">
                <div class="media-post-wrap">
                        <div class="thumb mb-4">
                            <img src="assets/img/blog/social-1.png" alt="img">
                        </div>
                        <div class="media-body ms-0">
                            <a class="tag top-right tag-yellow" href="#">Technology</a>
                            <h4><a href="blog-category.html">The golden rules of midlife fitness and things getting wrong.</a></h4>
                        </div>
                        <div class="meta d-flex">
                            <div class="author">
                                <div class="thumb">
                                    <img src="assets/img/banner/user.jpeg" alt="img">
                                </div>
                                <a href="#">Stiven Jackson</a>
                            </div>
                            <div class="date ms-auto">
                                <i class="fa fa-clock-o"></i>
                                    Mar 16, 2022						
                            </div>
                            <div class="comment ms-auto">
                                0
                            </div>
                        </div>
                    </div>
                </div>
                

                <div class="col-lg-6 col-md-6">
                    <div class="media-post-wrap">
                        <div class="thumb mb-4">
                            <img src="assets/img/blog/social-1.png" alt="img">
                        </div>
                        <div class="media-body ms-0">
                            <a class="tag top-right tag-yellow" href="#">Technology</a>
                            <h4><a href="blog-category.html">The golden rules of midlife fitness and things getting wrong.</a></h4>
                        </div>
                        <div class="meta d-flex">
                            <div class="author">
                                <div class="thumb">
                                    <img src="assets/img/banner/user.jpeg" alt="img">
                                </div>
                                <a href="#">Stiven Jackson</a>
                            </div>
                            <div class="date ms-auto">
                                <i class="fa fa-clock-o"></i>
                                    Mar 16, 2022						
                            </div>
                            <div class="comment ms-auto">
                                0
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="media-post-wrap">
                        <div class="thumb mb-4">
                            <img src="assets/img/blog/social-1.png" alt="img">
                        </div>
                        <div class="media-body ms-0">
                            <a class="tag top-right tag-yellow" href="#">Technology</a>
                            <h4><a href="blog-category.html">The golden rules of midlife fitness and things getting wrong.</a></h4>
                        </div>
                        <div class="meta d-flex">
                            <div class="author">
                                <div class="thumb">
                                    <img src="assets/img/banner/user.jpeg" alt="img">
                                </div>
                                <a href="#">Stiven Jackson</a>
                            </div>
                            <div class="date ms-auto">
                                <i class="fa fa-clock-o"></i>
                                    Mar 16, 2022						
                            </div>
                            <div class="comment ms-auto">
                                0
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="media-post-wrap">
                        <div class="thumb mb-4">
                            <img src="assets/img/blog/social-1.png" alt="img">
                        </div>
                        <div class="media-body ms-0">
                            <a class="tag top-right tag-yellow" href="#">Technology</a>
                            <h4><a href="blog-category.html">The golden rules of midlife fitness and things getting wrong.</a></h4>
                        </div>
                        <div class="meta d-flex">
                            <div class="author">
                                <div class="thumb">
                                    <img src="assets/img/banner/user.jpeg" alt="img">
                                </div>
                                <a href="#">Stiven Jackson</a>
                            </div>
                            <div class="date ms-auto">
                                <i class="fa fa-clock-o"></i>
                                    Mar 16, 2022						
                            </div>
                            <div class="comment ms-auto">
                                0
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="media-post-wrap">
                        <div class="thumb mb-4">
                            <img src="assets/img/blog/social-1.png" alt="img">
                        </div>
                        <div class="media-body ms-0">
                            <a class="tag top-right tag-yellow" href="#">Technology</a>
                            <h4><a href="blog-category.html">The golden rules of midlife fitness and things getting wrong.</a></h4>
                        </div>
                        <div class="meta d-flex">
                            <div class="author">
                                <div class="thumb">
                                    <img src="assets/img/banner/user.jpeg" alt="img">
                                </div>
                                <a href="#">Stiven Jackson</a>
                            </div>
                            <div class="date ms-auto">
                                <i class="fa fa-clock-o"></i>
                                    Mar 16, 2022						
                            </div>
                            <div class="comment ms-auto">
                                0
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="media-post-wrap">
                        <div class="thumb mb-4">
                            <img src="assets/img/blog/social-1.png" alt="img">
                        </div>
                        <div class="media-body ms-0">
                            <a class="tag top-right tag-yellow" href="#">Technology</a>
                            <h4><a href="blog-category.html">The golden rules of midlife fitness and things getting wrong.</a></h4>
                        </div>
                        <div class="meta d-flex">
                            <div class="author">
                                <div class="thumb">
                                    <img src="assets/img/banner/user.jpeg" alt="img">
                                </div>
                                <a href="#">Stiven Jackson</a>
                            </div>
                            <div class="date ms-auto">
                                <i class="fa fa-clock-o"></i>
                                    Mar 16, 2022						
                            </div>
                            <div class="comment ms-auto">
                                0
                            </div>
                        </div>
                    </div>
                </div>                 
                <div class="pagination-area text-center">
                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                              <li class="page-item"><a class="page-link active" href="#">1</a></li>
                              <li class="page-item"><a class="page-link" href="#">2</a></li>
                              <li class="page-item"><a class="page-link" href="#">...</a></li>
                              <li class="page-item"><a class="page-link" href="#">5</a></li>
                              <li class="page-item"><a class="page-link" href="#"><i class="fa fa-long-arrow-right"></i></a></li>
                            </ul>
                        </nav>
               </div>
                    </div>
                </div>
            
            
                <div class="col-lg-4">
                    <div class="side-area padding-new-1">
                        <div class="widget widget_search">
                            <h5 class="widget-title">
                                Search
                            </h5>
                            <div class="subscribe-inner">
                                <input type="text">
                                <button class="btn">Search</button>
                            </div>
                        </div>
                        <div class="widget widget_list mt-5">
                            <h4 class="widget-title">Categories</h4>
                            <ul class="list-inner">
                                <li><a href="#">Business</a></li>
                                <li><a href="#">Marketing</a></li>
                                <li><a href="#">Motivation</a></li>
                                <li><a href="#">Politics</a></li>
                                <li><a href="#">Sports</a></li>
                                <li><a href="#">Technology</a></li>
                                <li><a href="#">Travel</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- blog-area end -->

    <!-- footer area start -->
    <?php include 'includes/footer.php' ?>
    <!-- footer area end -->
